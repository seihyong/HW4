//
//  main.m
//  HW4
//
//  Created by SEI-HYONG PARK on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"HW4AppDelegate");
    [pool release];
    return retVal;
}
