//
//  View.h
//  HW4
//
//  Created by SEI-HYONG PARK on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View : UIView {
	//NSArray *mySwitches;
	UISwitch *mySwitch0;
	UISwitch *mySwitch1;
	UISwitch *mySwitch2;
	UIButton *button;

}

@end
