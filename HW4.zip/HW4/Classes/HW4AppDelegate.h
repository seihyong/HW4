//
//  HW4AppDelegate.h
//  HW4
//
//  Created by SEI-HYONG PARK on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
@class View;

@interface HW4AppDelegate : NSObject <UIApplicationDelegate> {
    MPMoviePlayerController *controller;
	View *view;
	UIWindow *window;
}

- (void) touchUpInside: (id) sender;

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

