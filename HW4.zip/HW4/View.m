//
//  View.m
//  HW4
//
//  Created by SEI-HYONG PARK on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"

@implementation View

- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame])) {
		// Initialization code
		self.backgroundColor = [UIColor blackColor];

		
		//Center the button in the view.
		CGSize s = CGSizeMake(200, 40);	//size of button
		CGRect b = self.bounds;
		
		CGRect f = CGRectMake(
							  b.origin.x + (b.size.width - s.width) / 2,
							  b.origin.y + (b.size.height - s.height) / 2,
							  s.width,
							  s.height
							  );
		
		button = [UIButton buttonWithType: UIButtonTypeRoundedRect];
		[button retain];
		button.frame = f;
		
		[button setTitleColor: [UIColor redColor]
					 forState: UIControlStateNormal];
		[button setTitle: @"Fred Ott’s Sneeze"
				forState: UIControlStateNormal];
		
		[button addTarget: [UIApplication sharedApplication].delegate
				   action: @selector(touchUpInside:)
		 forControlEvents: UIControlEventTouchUpInside
		 ];
		
		[self addSubview: button];
		 
		
//		mySwitches = [NSArray arrayWithObjects:
//					  mySwitch0 = [[UISwitch alloc] initWithFrame:CGRectZero],
//					  mySwitch1 = [[UISwitch alloc] initWithFrame:CGRectZero],
//					  mySwitch2 = [[UISwitch alloc] initWithFrame:CGRectZero],					  
//					  nil
//					  ];
//		for (UISwitch *s in mySwitches) {
//			int i = 0;
//			
//			[s			addTarget: self
//						   action: @selector(setNeedsDisplay)
//				 forControlEvents: UIControlEventValueChanged
//			 ];
//			s.center = CGPointMake(100,100*i);
//			[self addSubview: s];
//			i++;
//		}
		mySwitch0 = [[UISwitch alloc] initWithFrame:CGRectZero];
		mySwitch1 = [[UISwitch alloc] initWithFrame:CGRectZero];
		mySwitch2 = [[UISwitch alloc] initWithFrame:CGRectZero];
		
		[mySwitch0 addTarget: self
					 action: @selector(setNeedsDisplay)
		   forControlEvents: UIControlEventValueChanged
		 ];
		[mySwitch1 addTarget: self
					  action: @selector(setNeedsDisplay)
			forControlEvents: UIControlEventValueChanged
		 ];
		[mySwitch2 addTarget: self
					  action: @selector(setNeedsDisplay)
			forControlEvents: UIControlEventValueChanged
		 ];
		
		mySwitch0.center = CGPointMake(47+20, 13.5); //sometimes there's a place in life for brute force
		mySwitch1.center = CGPointMake(141+20, 13.5);
		mySwitch2.center = CGPointMake(235+20, 13.5);
		
		[self addSubview: mySwitch0];
		[self addSubview: mySwitch1];
		[self addSubview: mySwitch2];
	}
	return self;
}


 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void) drawRect: (CGRect) rect {
	 UIFont *f = [UIFont systemFontOfSize: 15.0];
	 NSString *s = @"play with switch to change background color";
	 CGPoint p = CGPointMake(10.0, 100.0);
	 CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 1, 1, 1, 1);
	 [s drawAtPoint: p withFont: f];
	 
	 int a; int b; int c;
	 if (mySwitch0.on == YES) {
		 a = 1;
	 }
	 else {
		 a = 0;
	 }
	 
	 if (mySwitch1.on == YES) {
		 b = 1;
	 }
	 else{
		 b=0;
	 }
	 
	 if (mySwitch2.on == YES) {
		 c = 1;
	 }
	 else{
		 c=0;
	 }
	 
		 self.backgroundColor=[UIColor
							   colorWithRed:a
							   green:b
							   blue:c
							   alpha:1.0];

 }

- (void) dealloc {
//	for (UISwitch *s in mySwitches){
//		[s release];
//	}
	[mySwitch0 release];
	[mySwitch1 release];
	[mySwitch2 release];
	[super dealloc];
}


@end