//
//  View.h
//  VC
//
//  Created by SEI-HYONG PARK on 7/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View : UIView {
	UIView *paddle;
	UIView *paddle1;
	UIView *ball;
	CGFloat dx, dy;

}

-(void) move: (CADisplayLink *) displayLink;

@end
