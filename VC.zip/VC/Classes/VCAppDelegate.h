//
//  VCAppDelegate.h
//  VC
//
//  Created by SEI-HYONG PARK on 7/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController;	//new

@interface VCAppDelegate : NSObject <UIApplicationDelegate> {
    ViewController *viewController;
	UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

