//
//  View.m
//  VC
//
//  Created by SEI-HYONG PARK on 7/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

//score if goes in

#import "View.h"
#import <QuartzCore/QuartzCore.h>

@implementation View

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
		self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"table.png"]];

		frame = CGRectMake(130,400,60,60);
		paddle = [[UIView alloc] initWithFrame:frame];
		paddle.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"puck1.png"]];
		[paddle setOpaque:NO];
		[self addSubview:paddle];

		frame = CGRectMake(130,40,60,60);
		paddle1 = [[UIView alloc] initWithFrame:frame];
		paddle1.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"puck1.png"]];
		[paddle1 setOpaque:NO];
		[self addSubview:paddle1];
		
		frame = CGRectMake(0,0,30,30);
		ball = [[UIView alloc] initWithFrame: frame];
		ball.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ball.png"]];
		[self addSubview: ball];
		
		dx = 2;
		dy = 2;
	}
    return self;
}

- (void) bounce {	
	//Where the ball would be if its horizontal motion were allowed
	//to continue for one more move.
	CGRect horizontal = ball.frame;
	horizontal.origin.x += dx;
	
	//Where the ball would be if its vertical motion were allowed
	//to continue for one more move.
	CGRect vertical = ball.frame;
	vertical.origin.y += dy;
	
	//Ball must remain inside self.bounds.
	if (!CGRectEqualToRect(horizontal, CGRectIntersection(horizontal, self.bounds))) {
		//Ball will bounce off left or right edge of View.
		dx = -dx/2;
	}
	
	if (!CGRectEqualToRect(vertical, CGRectIntersection(vertical, self.bounds))) {
		//Ball will bounce off top or bottom edge of View.
		dy = -dy/2;
	}
	
	//If the ball is not currently intersecting the paddle,
	if (!CGRectIntersectsRect(ball.frame, paddle.frame)) {
		
		//but if the ball will intersect the paddle on the next move,
		if (CGRectIntersectsRect(horizontal, paddle.frame)
			||CGRectIntersectsRect(horizontal, paddle1.frame)) {
			dx = -dx*2;
		}
		
		if (CGRectIntersectsRect(vertical, paddle.frame)
			||CGRectIntersectsRect(vertical, paddle1.frame)) {
			dy = -dy*2;
		}
	}
}

- (void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event {
	UITouch *t = [touches anyObject];
	CGPoint p = [t locationInView: self];
	CGFloat x = p.x;
	CGFloat y = p.y;
	
	//Don't let the paddle move off the bottom or top of the View.
	CGFloat half = paddle.bounds.size.width / 2;
	x = MIN(x, self.bounds.size.width - half-10);
	x = MAX(x, half+10);                         	
	y = MIN(y,430);
	y = MAX(y,275);
	paddle.center = CGPointMake(x,y);
	
	CGPoint pad1point = [[touches anyObject] locationInView: self];
	CGFloat pad1x = pad1point.x;
	CGFloat pad1y = pad1point.y;
	pad1x = MIN(pad1x, self.bounds.size.width - half-10);
	pad1x = MAX(pad1x, half+10);                         	
	pad1y = MIN(pad1y,200);
	pad1y = MAX(pad1y,50);
	paddle1.center = CGPointMake(pad1x,pad1y);	
	
	[self bounce];
}

-(void) move: (CADisplayLink *) displayLink{
	//NSLog(@"%.15g", displayLink.timestamp);
	ball.center = CGPointMake(ball.center.x+dx, ball.center.y+dy);
	[self bounce];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
	[paddle release];
	[paddle1 release];
	[ball release];
    [super dealloc];
}


@end
